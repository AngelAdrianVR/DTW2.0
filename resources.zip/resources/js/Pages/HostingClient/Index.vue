<script setup>
import { ref, computed } from 'vue';
import { Link, router, useForm } from '@inertiajs/vue3';
import { useToast } from 'primevue/usetoast';
import { useConfirm } from "primevue/useconfirm";
import AppLayout from '@/Layouts/AppLayout.vue';
import Menu from 'primevue/menu';
import ConfirmDialog from 'primevue/confirmdialog';
import Dialog from 'primevue/dialog';
import InputNumber from 'primevue/inputnumber';
import Calendar from 'primevue/calendar';
import Textarea from 'primevue/textarea';
import Card from 'primevue/card';
import Tag from 'primevue/tag';
import Button from 'primevue/button';
import DataTable from 'primevue/datatable';
import Column from 'primevue/column';


// --- PROPS ---
const props = defineProps({
    hostingClients: {
        type: Array,
        required: true,
    }
});

// --- STATE MANAGEMENT ---
const toast = useToast();
const confirm = useConfirm();
const menu = ref();
const selectedHostingClientForMenu = ref(null);
const isPaymentDialogVisible = ref(false);
const selectedHostingClientForPayment = ref(null);

// --- FORMS ---
const paymentForm = useForm({
    amount: null,
    payment_date: new Date().toISOString().slice(0, 10),
    notes: '',
    receipt: null,
});


// --- MENU ACTIONS ---
const menuItems = computed(() => {
    if (!selectedHostingClientForMenu.value) return [];
    const hc = selectedHostingClientForMenu.value;

    const items = [
        {
            label: 'Agregar Pago',
            icon: 'pi pi-dollar',
            command: () => openPaymentDialog(hc)
        },
        {
            label: 'Editar Registro',
            icon: 'pi pi-pencil',
            command: () => router.get(route('hosting-clients.edit', hc.id))
        },
    ];

    if (hc.status === 'Activo') {
        items.push({
            label: 'Cancelar Servicio',
            icon: 'pi pi-times-circle',
            command: () => confirmUpdateStatus(hc, 'Cancelado')
        });
    } else {
         items.push({
            label: 'Reactivar Servicio',
            icon: 'pi pi-check-circle',
            command: () => confirmUpdateStatus(hc, 'Activo')
        });
    }

    items.push(
        { separator: true },
        {
            label: 'Eliminar Registro',
            icon: 'pi pi-trash',
            command: () => confirmDeleteHostingClient(hc)
        }
    );
    
    return items;
});


const toggleMenu = (event, hostingClient) => {
    selectedHostingClientForMenu.value = hostingClient;
    menu.value.toggle(event);
};

// --- METHODS ---
const confirmUpdateStatus = (hostingClient, newStatus) => {
    const action = newStatus === 'Activo' ? 'reactivar' : 'cancelar';
     confirm.require({
        message: `¿Estás seguro de que quieres ${action} el servicio para "${hostingClient.client.name}"?`,
        header: 'Confirmación de cambio de estado',
        icon: 'pi pi-info-circle',
        accept: () => {
            updateStatus(hostingClient, newStatus);
        }
    });
};

const updateStatus = (hostingClient, newStatus) => {
    router.patch(route('hosting-clients.status.update', hostingClient.id), { status: newStatus }, {
        preserveScroll: true,
        onSuccess: () => {
             toast.add({
                severity: 'success', summary: 'Éxito',
                detail: 'Estado actualizado correctamente', life: 3000
            });
        },
        onError: () => {
            toast.add({
                severity: 'error', summary: 'Error',
                detail: 'No se pudo actualizar el estado.', life: 3000
            });
        }
    });
};


const confirmDeleteHostingClient = (hostingClient) => {
    confirm.require({
        message: `¿Estás seguro de que quieres eliminar el registro de hosting para "${hostingClient.client.name}"?`,
        header: 'Confirmación de eliminación',
        icon: 'pi pi-exclamation-triangle',
        rejectClass: 'p-button-text !text-zinc-600 dark:!text-zinc-600 !rounded-xl !px-4 !py-2 hover:!bg-zinc-100',
        acceptClass: '!bg-red-600 hover:!bg-red-700 !border-0 !rounded-xl !px-4 !py-2 !text-[var(--primary-text-color)]',
        acceptLabel: 'Eliminar',
        rejectLabel: 'Cancelar',
        accept: () => {
            deleteHostingClient(hostingClient);
        }
    });
};

const deleteHostingClient = (hostingClient) => {
    router.delete(route('hosting-clients.destroy', hostingClient.id), {
        preserveScroll: true,
        onSuccess: () => {
            toast.add({
                severity: 'success', summary: 'Éxito',
                detail: 'Registro de hosting eliminado', life: 3000
            });
        },
        onError: () => {
             toast.add({
                severity: 'error', summary: 'Error',
                detail: 'No se pudo eliminar el registro.', life: 3000
            });
        }
    });
};

const openPaymentDialog = (hostingClient) => {
    selectedHostingClientForPayment.value = hostingClient;
    paymentForm.reset();
    paymentForm.amount = hostingClient.payment_amount; // Pre-fill with the default amount
    isPaymentDialogVisible.value = true;
};

const closePaymentDialog = () => {
    isPaymentDialogVisible.value = false;
    selectedHostingClientForPayment.value = null;
    paymentForm.reset();
};

const handleFileChange = (event) => {
    paymentForm.receipt = event.target.files[0];
};

const submitPayment = () => {
    if (!selectedHostingClientForPayment.value) return;
    
    paymentForm.post(route('hosting-clients.payments.store', selectedHostingClientForPayment.value.id), {
        preserveScroll: true,
        forceFormData: true,
        onSuccess: () => {
            closePaymentDialog();
            toast.add({
                severity: 'success', summary: 'Éxito',
                detail: 'Pago registrado correctamente', life: 3000
            });
        },
        onError: (errors) => {
            const errorMessages = Object.values(errors).join(' ');
            toast.add({
                severity: 'error', summary: 'Error',
                detail: errorMessages || 'No se pudo registrar el pago.', life: 3000
            });
        }
    });
};


const onRowClick = (event) => {
    router.get(route('hosting-clients.show', event.data.id));
};

const rowClass = () => 'cursor-pointer hover:bg-gray-50 dark:hover:bg-zinc-800/50 transition-colors';

const formatCurrency = (value) => {
    if (value === null || isNaN(value)) value = 0;
    return new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(value);
};

const formatDate = (value) => {
    if (!value) return '';
    const date = new Date(value);
    date.setMinutes(date.getMinutes() + date.getTimezoneOffset());
    return date.toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
};

const getStatusSeverity = (status) => {
    const statusMap = { 'Activo': 'success', 'Suspendido': 'warning', 'Cancelado': 'danger' };
    return statusMap[status] || 'info';
};
</script>

<template>
    <AppLayout title="Clientes de Hosting">
        <div class="p-4 sm:p-6 lg:p-8">
            <div class="max-w-7xl mx-auto">
                <Toast />
                <ConfirmDialog />

                <header class="mb-8 flex justify-between items-center">
                    <div>
                        <h1 class="text-3xl font-bold dark:text-zinc-100 text-[#212121]">Módulo de Hosting</h1>
                        <p class="text-gray-400 dark:text-zinc-400 mt-1">Gestiona los servicios de hosting de tus clientes.</p>
                    </div>
                    <Link :href="route('hosting-clients.create')">
                        <Button label="Añadir Servicio" icon="pi pi-plus" class="!text-[var(--primary-text-color)]" />
                    </Link>
                </header>

                <!-- Desktop Table View -->
                <div class="hidden md:block bg-white dark:bg-zinc-900 rounded-2xl shadow-sm border border-gray-100 dark:border-zinc-800 overflow-hidden">
                    <DataTable :value="hostingClients" stripedRows paginator :rows="15" tableStyle="min-width: 50rem;"
                        @row-click="onRowClick" selectionMode="single" dataKey="id" :rowClass="rowClass" class="index-hosting-table">
                        <template #empty> <div class="p-4 text-center text-gray-500 dark:text-zinc-500">No se encontraron servicios de hosting.</div> </template>

                        <Column field="client.name" header="Cliente" sortable>
                            <template #body="{ data }">
                                <div class="font-semibold text-gray-800 dark:text-zinc-200">{{ data.client.name }}</div>
                            </template>
                        </Column>
                         <Column field="service_provider" header="Proveedor" sortable>
                             <template #body="{ data }">
                                <span class="text-gray-600 dark:text-zinc-400">{{ data.service_provider }}</span>
                            </template>
                         </Column>
                        <Column field="next_payment_date" header="Próximo Pago" sortable>
                            <template #body="{ data }">
                                <span class="text-gray-600 dark:text-zinc-400">{{ formatDate(data.next_payment_date) }}</span>
                            </template>
                        </Column>
                        <Column field="payment_amount" header="Monto" sortable class="text-right">
                            <template #body="{ data }">
                                <span class="text-emerald-600 dark:text-emerald-400">{{ formatCurrency(data.payment_amount) }}</span>
                            </template>
                        </Column>
                         <Column field="billing_cycle" header="Ciclo" sortable>
                             <template #body="{ data }">
                                <span class="text-gray-600 dark:text-zinc-400">{{ data.billing_cycle }}</span>
                            </template>
                         </Column>
                        <Column field="status" header="Estado" sortable>
                            <template #body="{ data }">
                                <Tag :value="data.status" :severity="getStatusSeverity(data.status)" />
                            </template>
                        </Column>
                        <Column header="Acciones" style="width: 10%" bodyClass="text-center">
                            <template #body="{ data }">
                                <Button icon="pi pi-ellipsis-v" text rounded aria-haspopup="true"
                                    aria-controls="overlay_menu" @click.stop="toggleMenu($event, data)" class="!text-gray-500 dark:!text-zinc-400 hover:!bg-gray-100 dark:hover:!bg-zinc-800" />
                            </template>
                        </Column>
                    </DataTable>
                </div>

                <Menu ref="menu" id="overlay_menu" :model="menuItems" :popup="true" />

                 <!-- Mobile Card View -->
                <div class="md:hidden grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Card v-for="hosting in hostingClients" :key="hosting.id" @click="onRowClick({data: hosting})" class="cursor-pointer dark:bg-zinc-900 dark:border-zinc-800 border border-gray-100 shadow-sm !rounded-xl">
                         <template #title>
                            <div class="flex justify-between items-start mb-2">
                                <span class="text-lg font-bold text-gray-800 dark:text-zinc-100">{{ hosting.client.name }}</span>
                                <Tag :value="hosting.status" :severity="getStatusSeverity(hosting.status)" />
                            </div>
                        </template>
                        <template #subtitle><span class="text-gray-500 dark:text-zinc-500">{{ hosting.service_provider }}</span></template>
                        <template #content>
                            <ul class="space-y-2 text-gray-600 dark:text-zinc-300 text-sm">
                                <li class="flex justify-between"><span>Próximo Pago:</span> <span class="font-medium text-gray-800 dark:text-zinc-200">{{ formatDate(hosting.next_payment_date) }}</span></li>
                                 <li class="flex justify-between border-t border-gray-100 dark:border-zinc-800 pt-2 mt-2">
                                    <span class="font-bold">Monto:</span>
                                    <span class="font-bold text-emerald-600 dark:text-emerald-400">
                                        {{ formatCurrency(hosting.payment_amount) }} ({{ hosting.billing_cycle }})
                                    </span>
                                </li>
                            </ul>
                        </template>
                        <template #footer>
                             <div class="flex justify-end">
                                <Button label="Acciones" icon="pi pi-bars" @click.stop="toggleMenu($event, hosting)"
                                    aria-haspopup="true" aria-controls="overlay_menu" severity="secondary" size="small" outlined />
                            </div>
                        </template>
                    </Card>
                    <div v-if="hostingClients.length === 0" class="text-center text-gray-500 dark:text-zinc-500 col-span-full mt-8">
                        No se encontraron servicios de hosting.
                    </div>
                </div>


                <!-- Payment Dialog (Apple Style) -->
                <Dialog v-model:visible="isPaymentDialogVisible" modal header="Registrar Pago" :style="{ width: '28rem' }"
                    :pt="{ 
                        root: { class: 'dark:bg-zinc-900 rounded-[2rem] shadow-2xl border-0' }, 
                        header: { class: 'pt-8 px-8 pb-0 bg-transparent rounded-t-[2rem] dark:text-zinc-100' }, 
                        content: { class: 'px-8 pb-8 pt-4 bg-transparent rounded-b-[2rem]' } 
                    }">
                    <template #header>
                        <div class="flex items-center gap-3 w-full">
                            <div class="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center">
                                <i class="pi pi-dollar text-emerald-600 dark:text-emerald-400 text-lg font-bold"></i>
                            </div>
                            <div class="flex flex-col">
                                <span class="text-xl font-bold text-gray-800 dark:text-white tracking-tight">Registrar Pago</span>
                                <span class="text-xs text-gray-500 dark:text-zinc-400">Para: {{ selectedHostingClientForPayment?.client?.name }}</span>
                            </div>
                        </div>
                    </template>
                    <form @submit.prevent="submitPayment">
                        <div class="flex flex-col gap-5 mt-2">
                            <div class="flex flex-col gap-2">
                                <label for="amount" class="text-sm font-semibold text-gray-700 dark:text-zinc-300">Monto del Pago <span class="text-red-500">*</span></label>
                                <InputNumber id="amount" v-model="paymentForm.amount" mode="currency" currency="MXN" locale="es-MX" class="!rounded-xl w-full" :class="{ 'p-invalid': paymentForm.errors.amount }" required />
                                <small v-if="paymentForm.errors.amount" class="p-error">{{ paymentForm.errors.amount }}</small>
                            </div>
                            <div class="flex flex-col gap-2">
                                <label for="payment_date" class="text-sm font-semibold text-gray-700 dark:text-zinc-300">Fecha del Pago <span class="text-red-500">*</span></label>
                                <Calendar id="payment_date" v-model="paymentForm.payment_date" dateFormat="yy-mm-dd" class="!rounded-xl w-full" :class="{ 'p-invalid': paymentForm.errors.payment_date }" required />
                                <small v-if="paymentForm.errors.payment_date" class="p-error">{{ paymentForm.errors.payment_date }}</small>
                            </div>
                            
                            <!-- Campo de Archivo (Comprobante) -->
                            <div class="flex flex-col gap-2">
                                <label class="text-sm font-semibold text-gray-700 dark:text-zinc-300">Subir Comprobante (Opcional)</label>
                                <input type="file" @change="handleFileChange" accept=".pdf,.jpg,.jpeg,.png"
                                    class="block w-full text-sm text-gray-500 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100 dark:file:bg-zinc-800 dark:file:text-emerald-400 transition-colors cursor-pointer" />
                                <small v-if="paymentForm.errors.receipt" class="p-error">{{ paymentForm.errors.receipt }}</small>
                            </div>

                            <div class="flex flex-col gap-2">
                                <label for="notes" class="text-sm font-semibold text-gray-700 dark:text-zinc-300">Notas Adicionales</label>
                                <Textarea id="notes" v-model="paymentForm.notes" rows="2" class="!rounded-xl w-full" />
                            </div>
                        </div>
                    </form>
                    <template #footer>
                        <div class="flex justify-end gap-3 mt-4 w-full">
                            <Button label="Cancelar" text severity="secondary" @click="closePaymentDialog" class="!rounded-xl font-medium" />
                            <Button label="Guardar Pago" icon="pi pi-check" @click="submitPayment" :loading="paymentForm.processing" class="!rounded-xl font-medium bg-emerald-600 border-emerald-600 hover:bg-emerald-700 !text-[var(--primary-text-color)]" />
                        </div>
                    </template>
                </Dialog>
            </div>
        </div>
    </AppLayout>
</template>

<style scoped>
/* Estilos para asegurar que el autocompletado del navegador no altere el diseño */
.p-inputtext, .p-inputnumber-input {
    width: 100% !important;
}
</style>

<style>
/* Estilos globales para la tabla de INDEX */
.index-hosting-table .p-datatable-thead > tr > th {
    background-color: #212121 !important;
    color: #d0d0d0 !important;
    border-bottom: 1px solid #e4e4e7 !important;
}

.index-hosting-table .p-datatable-tbody > tr { 
    background-color: transparent !important; 
}

.index-hosting-table .p-datatable-tbody > tr:not(:last-child) > td { 
    border-bottom: 1px solid #f4f4f5 !important; 
}

/* Reglas de Dark Mode para INDEX (Con el fondo claro que querías) */
html.dark .index-hosting-table .p-datatable-thead > tr > th,
.dark .index-hosting-table .p-datatable-thead > tr > th {
    background-color: #f4f4f5 !important;
    color: #52525b !important;
    border-bottom: 1px solid #27272a !important;
}

html.dark .index-hosting-table .p-datatable-tbody > tr:not(:last-child) > td,
.dark .index-hosting-table .p-datatable-tbody > tr:not(:last-child) > td { 
    border-bottom: 1px solid #27272a !important; 
}
</style>