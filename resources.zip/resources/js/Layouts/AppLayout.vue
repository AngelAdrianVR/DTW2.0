<script setup>
import { ref, computed, onMounted, watch } from 'vue';
import { Head, router } from '@inertiajs/vue3';
import Banner from '@/Components/Banner.vue';
import Sidebar from '@/Components/MyComponents/SideBar.vue';
import MobileSideBar from '@/Components/MyComponents/MobileSideBar.vue';
import DarkModeSwitch from '@/Components/MyComponents/DarkModeSwitch.vue';
import PomodoroTimer from '@/Components/MyComponents/PomodoroTimer.vue';
import { usePomodoro } from '@/Composables/usePomodoro';

const props = defineProps({
    title: String,
});

const { state, displayTime } = usePomodoro();

const isMobileMenuOpen = ref(false);

const pageTitle = computed(() => {
    if (state.isRunning) {
        return `${displayTime.value} - ${state.isWorkSession ? 'Enfoque' : 'Descanso'}`;
    }
    return props.title;
});

const navigationMenu = computed(() => [
    {
        name: 'Dashboard',
        route: 'dashboard',
        icon: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h7.5" /></svg>`,
        active: route().current('dashboard'),
        show: true,
    },
    {
        name: 'CRM',
        icon: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 3v11.25A2.25 2.25 0 0 0 6 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0 1 18 16.5h-2.25m-7.5 0h7.5m-7.5 0-1 3m8.5-3 1 3m0 0 .5 1.5m-.5-1.5h-9.5m0 0-.5 1.5m.75-9 3-3 2.148 2.148A12.061 12.061 0 0 1 16.5 7.605" /></svg>`,
        active: route().current('dashboard'),
        show: true,
        children: [
            {
                name: 'Clientes',
                route: 'clients.index',
                active: route().current('clients.*'),
            },
            {
                name: 'Cotizaciones',
                route: 'quotes.index',
                active: route().current('quotes.*'),
            }
        ]
    },
    {
        name: 'PMS',
        route: 'projects.index',
        icon: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="M20.25 14.15v4.25c0 1.094-.787 2.036-1.872 2.18-2.087.277-4.216.42-6.378.42s-4.291-.143-6.378-.42c-1.085-.144-1.872-1.086-1.872-2.18v-4.25m16.5 0a2.18 2.18 0 0 0 .75-1.661V8.706c0-1.081-.768-2.015-1.837-2.175a48.114 48.114 0 0 0-3.413-.387m4.5 8.006c-.194.165-.42.295-.673.38A23.978 23.978 0 0 1 12 15.75c-2.648 0-5.195-.429-7.577-1.22a2.016 2.016 0 0 1-.673-.38m0 0A2.18 2.18 0 0 1 3 12.489V8.706c0-1.081.768-2.015 1.837-2.175a48.111 48.111 0 0 1 3.413-.387m7.5 0V5.25A2.25 2.25 0 0 0 13.5 3h-3a2.25 2.25 0 0 0-2.25 2.25v.894m7.5 0a48.667 48.667 0 0 0-7.5 0M12 12.75h.008v.008H12v-.008Z" /></svg>`,
        active: route().current('projects.*'),
        show: true,
    },
    {
        name: 'RRHH',
        icon: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m.94 3.198.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0 1 12 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 0 1 6 18.719m12 0a5.971 5.971 0 0 0-.941-3.197m0 0A5.995 5.995 0 0 0 12 12.75a5.995 5.995 0 0 0-5.058 2.772m0 0a3 3 0 0 0-4.681 2.72 8.986 8.986 0 0 0 3.74.477m.94-3.197a5.971 5.971 0 0 0-.94 3.197M15 6.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm6 3a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-13.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z" /></svg>`,
        active: route().current('dashboard'),
        show: true,
        children: [
            {
                name: 'Usuarios',
                route: 'users.index',
                active: route().current('users.*'),
            },
        ]
    },
    {
        name: 'Hostings',
        route: 'hosting-clients.index',
        icon: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="M12 21a9.004 9.004 0 0 0 8.716-6.747M12 21a9.004 9.004 0 0 1-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 0 1 7.843 4.582M12 3a8.997 8.997 0 0 0-7.843 4.582m15.686 0A11.953 11.953 0 0 1 12 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0 1 21 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0 1 12 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 0 1 3 12c0-1.605.42-3.113 1.157-4.418" /></svg>`,
        active: route().current('hosting-clients.*'),
        show: true,
    },
    {
        name: 'Recursos Web',
        route: 'admin.webcontents.index',
        icon: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6"><path stroke-linecap="round" stroke-linejoin="round" d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Zm10.5-11.25h.008v.008h-.008V8.25Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" /></svg>`,
        active: route().current('admin.webcontents.*'),
        show: true,
    },
    {
        name: 'TPSP',
        route: 'tpsp.index',
        icon: `<svg width="20" height="22" viewBox="0 0 16 18" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M10.728 10.2621C9.7486 7.23884 8.36383 5.12753 6.21435 2.68263C8.90193 4.24298 10.728 5.94849 11.4394 9.83631C11.8393 12.0218 12.5625 14.1849 13.4958 15.8403C12.1757 15.7125 11.0921 11.3862 10.728 10.2621Z" /><path d="M14.6569 16.4626C14.5139 16.3991 14.3387 16.3465 14.1345 16.3087C15.4545 16.3513 15.7526 16.9474 14.9435 17.6287C14.4642 18.0324 13.5356 18.1124 12.3035 17.8416C10.5151 17.4485 8.89698 16.0958 7.19372 13.6261C6.81049 13.0704 5.49046 11.5822 4.38334 11.5822C3.61688 11.5822 2.25415 11.497 1.82846 11.497C0.465917 11.4281 -0.598782 9.87889 0.380688 7.92015C1.10464 6.47238 1.50008 5.56644 1.87094 4.08782C2.18066 2.85296 1.62883 1.46312 0.380688 0H0.891549H1.20634C2.08346 1.06514 2.44628 1.81102 2.66226 3.662C2.66226 4.74215 2.33264 5.24898 1.20634 8.02838C0.784917 9.06833 0.95675 10.2812 1.82846 10.8154C2.09997 10.9818 3.15725 11.0722 4.38334 10.9818C5.60943 10.8915 8.30065 12.3537 11.1538 16.14C12.3495 17.1771 13.0402 17.4159 14.2622 17.3463C14.9378 17.2185 15.0698 16.7223 14.6569 16.4626Z" /></svg>`,
        active: route().current('tpsp.*'),
        show: true,
    },
]);

// --- Lógica para el Modo Oscuro ---
const isDarkMode = ref(false);

onMounted(() => {
    if (typeof window !== 'undefined') {
        if (localStorage.getItem('darkMode') === 'true' ||
           (!('darkMode' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            isDarkMode.value = true;
        }
    }
});

watch(isDarkMode, (newValue) => {
    if (typeof window !== 'undefined') {
        if (newValue) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
        localStorage.setItem('darkMode', newValue);
    }
});

const switchToTeam = (team) => {
    router.put(route('current-team.update'), {
        team_id: team.id,
    }, {
        preserveState: false,
    });
};
</script>

<template>
    <div>
        <Head :title="pageTitle" />
        <Banner />
        
        <PomodoroTimer />

        <div class="flex min-h-screen bg-[#ececec] dark:bg-zinc-950">
            <Sidebar :navigation="navigationMenu" />
            <MobileSideBar v-model:isOpen="isMobileMenuOpen" :navigation="navigationMenu" />

            <!-- Contenedor Principal Ajustado -->
            <div class="flex-1 flex flex-col w-full px-3 md:px-6 transition-all duration-300">
                
                <!-- Navbar "Flotante" y Redondeado -->
                <!-- 
                    Cambios en clases de Navbar:
                    - 'px-4 sm:px-6 lg:px-8' reemplazado por 'pl-4 sm:pl-6 lg:pl-8 pr-2'
                    - Esto da más padding a la izquierda (título/botón) y reduce el de la derecha para el Switch.
                    - El Switch mide 50px de alto. Navbar 64px (h-16). Diferencia vertical: 14px total (7px arriba/abajo).
                    - 'pr-2' añade 0.5rem (8px) a la derecha, equilibrando visualmente los 7px verticales.
                -->
                <nav class="bg-white/90 dark:bg-zinc-900/90 backdrop-blur-md shadow-sm border border-gray-100 dark:border-zinc-800 max-w-7xl mx-auto pl-4 sm:pl-6 lg:pl-8 pr-2 mt-1 rounded-[2rem] w-full z-20 sticky top-4">
                    <div class="w-full">
                        <div class="flex justify-between items-center h-14">
                           <!-- Lado Izquierdo: Botón Menú, Título del Proyecto y Timer -->
                            <div class="flex items-center gap-x-4">
                                <!-- Botón de Menú Móvil -->
                                <button @click="isMobileMenuOpen = true" class="lg:hidden p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-zinc-800 focus:outline-none transition-colors">
                                    <span class="sr-only">Open main menu</span>
                                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" /></svg>
                                </button>

                                <!-- TÍTULO DEL PROYECTO (Si se proporciona) -->
                                <div v-if="title" class="hidden md:flex flex-col border-l border-gray-200 dark:border-zinc-700 pl-4 h-10 justify-center">
                                    <h1 class="text-lg font-bold text-gray-800 dark:text-white leading-tight">
                                        {{ title }}
                                    </h1>
                                </div>
                                
                               <transition
                                    enter-active-class="transition ease-out duration-200"
                                    enter-from-class="opacity-0 scale-95"
                                    enter-to-class="opacity-100 scale-100"
                                    leave-active-class="transition ease-in duration-150"
                                    leave-from-class="opacity-100 scale-100"
                                    leave-to-class="opacity-0 scale-95"
                                >
                                    <div v-if="state.isRunning" class="flex items-center gap-x-2 px-3 py-1 rounded-full text-sm font-medium text-white shadow-sm"
                                        :class="state.isWorkSession ? 'bg-emerald-500/90' : 'bg-sky-500/90'">
                                        <svg v-if="state.isWorkSession" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-9v9" /></svg>
                                        <svg v-else class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75l3 3m0 0l3-3m-3 3v-7.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                        <span class="font-mono tracking-wider">{{ displayTime }}</span>
                                    </div>
                               </transition>
                            </div>

                            <!-- Lado Derecho: Switch de Modo Oscuro -->
                            <!-- El gap-3 se mantiene, pero al estar pegado a la derecha por 'justify-between' y el 'pr-2' del nav, queda alineado -->
                            <div class="flex items-center gap-3">
                                <DarkModeSwitch v-model="isDarkMode" />
                            </div>
                        </div>
                    </div>
                </nav>

                <!-- Contenido de la Página -->
                <main class="mt-6 lg:mx-auto h-[calc(100vh-8rem)] overflow-y-auto w-full custom-scrollbar pb-10">
                    <slot />
                </main>
            </div>
        </div>
    </div>
</template>

<style scoped>
/* Scrollbar moderno, delgado y sin flechas */
.custom-scrollbar {
    scrollbar-width: thin; /* Firefox */
    scrollbar-color: rgba(156, 163, 175, 0.5) transparent; /* Firefox */
}

/* Webkit (Chrome, Safari, Edge) */
.custom-scrollbar::-webkit-scrollbar {
    width: 6px;
    height: 6px;
}

.custom-scrollbar::-webkit-scrollbar-track {
    background: transparent;
}

.custom-scrollbar::-webkit-scrollbar-thumb {
    background-color: rgba(156, 163, 175, 0.5);
    border-radius: 20px;
    border: 2px solid transparent; /* Crea un efecto de margen */
    background-clip: content-box;
    transition: background-color 0.3s;
}

.custom-scrollbar::-webkit-scrollbar-thumb:hover {
    background-color: rgba(156, 163, 175, 0.8);
}

/* Modo oscuro para el scrollbar */
.dark .custom-scrollbar::-webkit-scrollbar-thumb {
    background-color: rgba(82, 82, 91, 0.5); /* zinc-600 con opacidad */
}

.dark .custom-scrollbar::-webkit-scrollbar-thumb:hover {
    background-color: rgba(82, 82, 91, 0.8);
}

/* Ocultar flechas explícitamente */
.custom-scrollbar::-webkit-scrollbar-button {
    display: none;
    width: 0;
    height: 0;
}
</style>