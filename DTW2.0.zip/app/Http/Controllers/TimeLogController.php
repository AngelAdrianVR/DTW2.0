<?php

namespace App\Http\Controllers;

use App\Models\TimeLog;
use Illuminate\Http\Request;

class TimeLogController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(TimeLog $timeLog)
    {
        //
    }

    public function edit(TimeLog $timeLog)
    {
        //
    }

    public function update(Request $request, TimeLog $timeLog)
    {
        //
    }

    public function destroy(TimeLog $timeLog)
    {
        //
    }
}
