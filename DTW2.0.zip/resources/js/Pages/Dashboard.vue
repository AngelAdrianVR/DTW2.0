<script setup>
import AppLayout from '@/Layouts/AppLayout.vue';
import Welcome from '@/Components/Welcome.vue';
</script>

<template>
    <AppLayout title="Dashboard">
        <main>
            safiojhofhdsofihdsfoih
        </main>
    </AppLayout>
</template>
